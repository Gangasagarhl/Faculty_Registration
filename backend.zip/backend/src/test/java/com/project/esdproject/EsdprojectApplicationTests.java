package com.project.esdproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsdprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
