package com.project.esdproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsdprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(EsdprojectApplication.class, args);
	}

}
